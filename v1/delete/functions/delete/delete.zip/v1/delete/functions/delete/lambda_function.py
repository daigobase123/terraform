def lambda_handler(event, context):
    # ログを出力する
    print("event:", event)
    print("context:", context)
